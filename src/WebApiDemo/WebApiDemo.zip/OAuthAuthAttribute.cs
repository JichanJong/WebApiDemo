﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.Http;
using System.Net;
using System.Net.Http;
using System.Web.Http.Controllers;

namespace WebApiDemo
{
    public class OAuthAuthAttribute : AuthorizeAttribute
    {
        TokenBiz tBiz = new TokenBiz();
        public const string AuthorizationHeaderName = "Authorization";
        public const string WwwAuthenticationHeaderName = "WWW-Authenticate";
        public const string BasicAuthenticationScheme = "Basic";
        private static readonly bool HasInterfaceAuth = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["HasInterfaceAuth"]);
        /// <summary>
        /// 重写授权方法
        /// </summary>
        /// <param name="actionContext"></param>
        public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            if (HasInterfaceAuth)
            {
                IPrincipal user;
                if (this.IsAuthenticated(actionContext, out user))
                {

                    //最关键设置 当前线程用户安全信息

                    Thread.CurrentPrincipal = user;
                    if (HttpContext.Current != null)
                    {
                        HttpContext.Current.User = user;
                    }
                }
                else
                {
                    this.ProcessUnauthenticatedRequest(actionContext);
                }
            }
        }


        /// <summary>
        /// 获取Authorization 头 例如：Basic:75DE784E62224B7DAB44F1D5CF37C908
        /// </summary>
        /// <param name="filterContext"></param>
        /// <returns></returns>
        protected virtual AuthenticationHeaderValue GetAuthenticationHeaderValue(System.Web.Http.Controllers.HttpActionContext filterContext)
        {


            IEnumerable<string> split = new List<string>();
            var rawValue = filterContext.Request.Headers.TryGetValues(AuthorizationHeaderName, out split);
            if (!rawValue)
            {
                return null;
            }
            var astr = split.FirstOrDefault();
            string[] asplit = astr.Split(':');
            if (asplit.Length != 2)
            {
                return null;
            }
            return new AuthenticationHeaderValue(asplit[0], asplit[1]);


        }


        /// <summary>
        /// 检索是否授权
        /// </summary>
        /// <param name="filterContext"></param>
        /// <param name="user"></param>
        /// <returns></returns>
        protected virtual bool IsAuthenticated(System.Web.Http.Controllers.HttpActionContext filterContext, out IPrincipal user)
        {
            user = HttpContext.Current.User;
            if (null != user & user.Identity.IsAuthenticated)
            {
                return true;
            }


            AuthenticationHeaderValue token = this.GetAuthenticationHeaderValue(filterContext);
            if (null != token && token.Scheme == BasicAuthenticationScheme)
            {
                string credential = token.Parameter;
                var entity = tBiz.GetEntityByToken(credential);
                if (entity != null)
                {
                    string uid = string.IsNullOrEmpty(entity.UIID) ? entity.UserID.ToString() : entity.UIID;
                    GenericIdentity identity = new GenericIdentity(uid);
                    user = new GenericPrincipal(identity, new string[0]);
                    filterContext.ActionArguments["AuthState"] = AuthState.Success;
                    return true;
                }
                else
                {
                    filterContext.ActionArguments["AuthState"] = AuthState.Failure;
                }
            }
            else
            {
                filterContext.ActionArguments["AuthState"] = AuthState.Failure;
            }


            return false;
        }


        /// <summary>
        /// 失败或者不存在返回json参数
        /// </summary>
        /// <param name="filterContext"></param>
        protected virtual void ProcessUnauthenticatedRequest(System.Web.Http.Controllers.HttpActionContext filterContext)
        {
            AuthState state = (AuthState)filterContext.ActionArguments["AuthState"];
            string parameter = string.Format("realm=\"{0}\"", filterContext.Request.RequestUri.DnsSafeHost);
            AuthenticationHeaderValue challenge = new AuthenticationHeaderValue(BasicAuthenticationScheme, parameter);
            if (state == AuthState.Invalid)
            {
                var rp = filterContext.Request.CreateResponse<ErrorResult>(HttpStatusCode.OK,
                               new ErrorResult { Code = CodeEnum.Token已过期, Message = CodeEnum.Token已过期.ToString() });
                rp.Headers.Add(WwwAuthenticationHeaderName, challenge.ToString());
                filterContext.Response = rp;


            }
            if (state == AuthState.Failure)
            {
                var rp = filterContext.Request.CreateResponse<ErrorResult>(HttpStatusCode.OK,
                               new ErrorResult { Code = CodeEnum.Token不存在, Message = CodeEnum.Token不存在.ToString() });
                rp.Headers.Add(WwwAuthenticationHeaderName, challenge.ToString());
                filterContext.Response = rp;


            }
        }

    }
    /// <summary>
    /// 返回参数枚举
    /// </summary>
    public enum AuthState : int
    {
        Success = 0,
        Failure = 1,
        Invalid = 2
    }
}