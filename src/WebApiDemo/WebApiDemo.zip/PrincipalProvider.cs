﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;

namespace WebApiDemo
{
    public class PrincipalProvider : IProvidePrincipal
    {
        public readonly string UserName = "admin";
        public readonly string Password = "123";
        public IPrincipal CreatePrincipal(string username, string password)
        {
            if (username != UserName || password != Password)
            {
                return null;
            }
            var identity = new GenericIdentity(UserName);
            IPrincipal principal = new GenericPrincipal(identity, new[] { "User" });
            return principal;
        }
    }
}